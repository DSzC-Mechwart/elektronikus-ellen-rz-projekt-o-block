﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace elektronikus_ellenorzo
{
    public class Tantárgy
    {
        public string Név { get; private set; } // Csak olvasható a kívülről

        public int Évfolyam { get; set; }
        public bool IsKözismereti { get; set; }
        public int HetiÓraszám { get; set; }

        public int ÉvesÓraszám => SzámoljÉvesÓraszámot();

        public Tantárgy(string név)
        {
            Név = név ?? throw new ArgumentNullException(nameof(név)); // Kivétel dobása, ha null
        }

        private int SzámoljÉvesÓraszámot()
        {
            int tanításiHét = 36; // Alapértelmezett

            if (Évfolyam == 12)
            {
                tanításiHét = IsKözismereti ? 31 : 36;
            }
            else if (Évfolyam == 13)
            {
                tanításiHét = 31;
            }

            return HetiÓraszám * tanításiHét;
        }
    }


}