﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using elektronikus_ellenorzo;
using System.Linq;


namespace elektronikus_ellenorzo
{
    public partial class MainWindow : Window
    {
        private List<Tantárgy> tantárgyak = new List<Tantárgy>();

        public MainWindow()
        {
            InitializeComponent();
            // Évfolyamok feltöltése
            cmbÉvfolyam.Items.Add(9);
            cmbÉvfolyam.Items.Add(10);
            cmbÉvfolyam.Items.Add(11);
            cmbÉvfolyam.Items.Add(12);
            cmbÉvfolyam.Items.Add(13);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Tantárgy létrehozása és adatok beállítása
                Tantárgy újTantárgy = new Tantárgy(txtTantárgyNév.Text)
                {
                    Évfolyam = (int)cmbÉvfolyam.SelectedItem,
                    IsKözismereti = rdbKözismereti.IsChecked ?? false,
                    HetiÓraszám = int.Parse(txtHetiÓraszám.Text)
                };

                // Adatvalidálás
                if (string.IsNullOrEmpty(újTantárgy.Név))
                {
                    MessageBox.Show("Kérem, adja meg a tantárgy nevét!");
                    return;
                }
                if (újTantárgy.HetiÓraszám <= 0)
                {
                    MessageBox.Show("A heti óraszámnak pozitívnak kell lennie!");
                    return;
                }

                // Tantárgy hozzáadása a listához
                tantárgyak.Add(újTantárgy);

                // Adatmentés
                MentsFájlba(tantárgyak); // CSV
                MentsJSONba(tantárgyak);  // JSON

                // Üzenet a felhasználónak
                MessageBox.Show($"A tantárgy '{újTantárgy.Név}' éves óraszáma: {újTantárgy.ÉvesÓraszám}");

                // Mezők kiürítése
                txtTantárgyNév.Clear();
                cmbÉvfolyam.SelectedItem = null;
                rdbKözismereti.IsChecked = false;
                rdbSzakmai.IsChecked = false;
                txtHetiÓraszám.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt: " + ex.Message);
            }
        }

        private void Button_Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Ellenőrizzük, hogy a tantárgy neve meg van-e adva
                string tantargyNev = txtTantárgyNév.Text;
                if (string.IsNullOrEmpty(tantargyNev))
                {
                    MessageBox.Show("Kérem, adja meg a törlendő tantárgy nevét!");
                    return;
                }

                // Megkeressük a tantárgyat a listában
                var tantargyToRemove = tantárgyak.FirstOrDefault(t => t.Név.Equals(tantargyNev, StringComparison.OrdinalIgnoreCase));
                if (tantargyToRemove != null)
                {
                    // Törlés a listából
                    tantárgyak.Remove(tantargyToRemove);

                    // Adatmentés frissítése
                    MentsFájlba(tantárgyak); // CSV
                    MentsJSONba(tantárgyak);  // JSON

                    // Üzenet a felhasználónak
                    MessageBox.Show($"A tantárgy '{tantargyNev}' sikeresen törölve lett.");
                }
                else
                {
                    MessageBox.Show("A megadott tantárgy nem található.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt: " + ex.Message);
            }
        }

        private void Button_Admin_Click(object sender, RoutedEventArgs e)
        {
            var kimutatas = new StringBuilder();

            var csoportositas = tantárgyak
                .GroupBy(t => new { t.Évfolyam, t.IsKözismereti })
                .Select(g => new
                {
                    Évfolyam = g.Key.Évfolyam,
                    IsKözismereti = g.Key.IsKözismereti,
                    TantárgySzám = g.Count(),
                    ÖsszesÓraszám = g.Sum(t => t.ÉvesÓraszám)
                });

            foreach (var csoport in csoportositas)
            {
                kimutatas.AppendLine($"Évfolyam: {csoport.Évfolyam}, " +
                                      $"Tantárgy típusa: {(csoport.IsKözismereti ? "Közismereti" : "Szakmai")}, " +
                                      $"Tantárgyak száma: {csoport.TantárgySzám}, " +
                                      $"Összes óraszám: {csoport.ÖsszesÓraszám}");
            }

            MessageBox.Show(kimutatas.ToString(), "Kimutatás");
        }

        private int SzámoljÉvesÓraszámot(int évfolyam, bool isKözismereti, int hetiÓraszám)
        {
            int tanításiHét = 36; // Alapértelmezett

            if (évfolyam == 12)
            {
                tanításiHét = isKözismereti ? 31 : 36;
            }
            else if (évfolyam == 13)
            {
                tanításiHét = 31;
            }

            return hetiÓraszám * tanításiHét;
        }

        private void MentsFájlba(List<Tantárgy> tantárgyak)
        {
            using (StreamWriter writer = new StreamWriter("tantargyak.csv", false)) // false: felülírás
            {
                foreach (var tantargy in tantárgyak)
                {
                    writer.WriteLine($"{tantargy.Név};{tantargy.Évfolyam};{tantargy.IsKözismereti};{tantargy.HetiÓraszám};{tantargy.ÉvesÓraszám}");
                }
            }
        }

        private void MentsJSONba(List<Tantárgy> tantárgyak)
        {
            var json = System.Text.Json.JsonSerializer.Serialize(tantárgyak);
            File.WriteAllText("tantargyak.json", json);
        }

    }
    


}