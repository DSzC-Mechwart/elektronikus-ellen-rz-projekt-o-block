﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using Microsoft.Win32;

namespace StudentApp
{
    public partial class MainWindow : Window
    {
        private const string FilePath = "students.json";
        private Dictionary<string, List<Student>> studentRecords;

        public MainWindow()
        {
            InitializeComponent();
            studentRecords = LoadData();

            isBoarderCheckBox.Checked += (s, e) => dormNameTextBox.IsEnabled = true;
            isBoarderCheckBox.Unchecked += (s, e) => dormNameTextBox.IsEnabled = false;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Diák adatainak összegyűjtése
            string name = nameTextBox.Text;
            string birthPlace = birthPlaceTextBox.Text;
            string birthDate = birthDateTextBox.Text;
            DateTime enrollmentDate = DateTime.Parse(enrollmentDateTextBox.Text);
            string studentClass = classTextBox.Text;
            bool isBoarder = isBoarderCheckBox.IsChecked ?? false;
            string dormName = dormNameTextBox.Text;

            // Osztály ellenőrzése
            if (!studentRecords.ContainsKey(studentClass))
            {
                studentRecords[studentClass] = new List<Student>();
            }

            // Naplósorszám és törzslapszám generálás
            int logNumber = GenerateLogNumber(studentClass, enrollmentDate);
            string registryNumber = $"{logNumber}/{enrollmentDate.Year}";

            // Új diák hozzáadása
            Student newStudent = new Student
            {
                Name = name,
                BirthPlace = birthPlace,
                BirthDate = birthDate,
                EnrollmentDate = enrollmentDate,
                Class = studentClass,
                IsBoarder = isBoarder,
                DormName = dormName,
                LogNumber = logNumber,
                RegistryNumber = registryNumber
            };

            studentRecords[studentClass].Add(newStudent);
            SaveData(studentRecords);

            MessageBox.Show($"Diák hozzáadva!\nNaplósorszám: {logNumber}\nTörzslapszám: {registryNumber}");
        }

        private void AdminButton_Click(object sender, RoutedEventArgs e)
        {
            // Új admin ablak megnyitása
            AdminWindow adminWindow = new AdminWindow(studentRecords);
            adminWindow.ShowDialog();
        }

        private int GenerateLogNumber(string studentClass, DateTime enrollmentDate)
        {
            var students = studentRecords[studentClass];
            if (enrollmentDate < new DateTime(enrollmentDate.Year, 9, 1))
            {
                students = students.OrderBy(s => s.Name).ToList();
            }
            return students.Count + 1;
        }

        private void SaveData(Dictionary<string, List<Student>> records)
        {
            string json = JsonSerializer.Serialize(records);
            File.WriteAllText(FilePath, json);
        }

        private Dictionary<string, List<Student>> LoadData()
        {
            if (File.Exists(FilePath))
            {
                string json = File.ReadAllText(FilePath);
                return JsonSerializer.Deserialize<Dictionary<string, List<Student>>>(json);
            }
            return new Dictionary<string, List<Student>>();
        }
    }

    public class Student
    {
        public string Name { get; set; }
        public string BirthPlace { get; set; }
        public string BirthDate { get; set; }
        public DateTime EnrollmentDate { get; set; }
        public string Class { get; set; }
        public bool IsBoarder { get; set; }
        public string DormName { get; set; }
        public int LogNumber { get; set; }
        public string RegistryNumber { get; set; }
    }
}