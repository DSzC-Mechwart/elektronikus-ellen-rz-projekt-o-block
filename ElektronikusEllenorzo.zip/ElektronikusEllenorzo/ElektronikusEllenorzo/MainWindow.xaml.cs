﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ElektronikusEllenorzo
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // Allow user to specify the dorm in case the 'dorm resident' checkbox is ticked
            isBoarderCheckBox.Checked += (s, e) => dormNameTextBox.IsEnabled = true;
            isBoarderCheckBox.Unchecked += (s, e) => dormNameTextBox.IsEnabled = false;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Collect data
            string name = nameTextBox.Text;
            string birthPlace = birthPlaceTextBox.Text;
            string birthDate = birthDateTextBox.Text;
            string motherName = motherNameTextBox.Text;
            string address = addressTextBox.Text;
            string enrollmentDate = enrollmentDateTextBox.Text;

            // Write the data down in a MessageBox
            string message = $"Name: {name}\n" +
                             $"Birthplace: {birthPlace}\n" +
                             $"Date of birth: {birthDate}\n" +
                             $"Mother's name: {motherName}\n" +
                             $"Home address: {address}\n" +
                             $"Enrollment date: {enrollmentDate}\n" +
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}