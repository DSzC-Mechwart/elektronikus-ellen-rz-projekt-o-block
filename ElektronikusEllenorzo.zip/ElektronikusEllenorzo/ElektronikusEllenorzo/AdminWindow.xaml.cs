using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace StudentApp
{
    public partial class AdminWindow : Window
    {
        private Dictionary<string, List<Student>> students;

        public AdminWindow(Dictionary<string, List<Student>> studentRecords)
        {
            InitializeComponent();
            students = studentRecords;
            LoadStudents();
        }

        private void LoadStudents()
        {
            var allStudents = students.Values.SelectMany(s => s).ToList();
            studentDataGrid.ItemsSource = allStudents;
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedStudent = (Student)studentDataGrid.SelectedItem;
            if (selectedStudent != null)
            {
                var result = MessageBox.Show("Biztosan t�r�lni akarod ezt a tanul�t?", "Meger�s�t�s", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    students[selectedStudent.Class].Remove(selectedStudent);
                    LoadStudents();
                }
            }
        }

        private void StatsButton_Click(object sender, RoutedEventArgs e)
        {
            var totalBoarders = students.Values.SelectMany(s => s).Count(s => s.IsBoarder);
            var debrecenStudents = students.Values.SelectMany(s => s).Count(s => s.BirthPlace == "Debrecen");
            var dayStudents = students.Values.SelectMany(s => s).Count(s => !s.IsBoarder);

            var yearlyStats = students
                .Values.SelectMany(s => s)
                .GroupBy(s => s.EnrollmentDate.Year)
                .Select(g => $"�v: {g.Key}, Tanul�k: {g.Count()}").ToList();

            MessageBox.Show($"Koll�gist�k: {totalBoarders}\nDebreceniek: {debrecenStudents}\nBej�r�sok: {dayStudents}\n\n�ves statisztika:\n{string.Join("\n", yearlyStats)}");
        }
    }
}
